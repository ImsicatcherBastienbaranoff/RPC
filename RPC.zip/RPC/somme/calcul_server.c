#include "calcul.h"

void * 
calcul_null_1_svc(void *argp, struct svc_req *rqstp)
{
  static char* result;
  /* Ne rien faire */
  return((void*) &result);
}

reponse * 
calcul_addition_1_svc(data *argp, struct svc_req *rqstp)
{
  static reponse  result;
  unsigned int max;

  result.errno = 0; /* Pas d'erreur */

  /* Prend le max */
  max = argp->arg1 > argp->arg2 ? argp->arg1 : argp->arg2;

  /* On additionne */
  result.somme = argp->arg1 + argp->arg2; 

  /* Overflow ? */
  if ( result.somme < max ) {
    result.errno = 1;
  }
    
  return(&result);
}

